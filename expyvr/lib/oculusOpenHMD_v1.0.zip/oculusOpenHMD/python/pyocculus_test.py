
import platform, os
from ctypes import *
from ctypes.util import find_library
from ctypes.wintypes import BOOL
from time import sleep
from os import environ
from os.path import *

environ['PATH'] += ';' + dirname(abspath(__file__))

dllfile = find_library('../Release/oculusOpenHMD.dll')
if dllfile is None:
    print("Could not find .dll")
else:
    OVR = cdll.LoadLibrary(dllfile) 
    
    if OVR:
        r = OVR.initOculus()
        
        if r > 1:
            print "\n\n FOUND THE OCULUS \n\n"
            
            # OVR.initGL()
            
        OVR.endOculus()
    
    else:
        print "Could not load Oculus DLL"



