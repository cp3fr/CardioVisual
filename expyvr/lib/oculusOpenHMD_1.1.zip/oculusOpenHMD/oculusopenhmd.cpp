#include "oculusopenhmd.h"


#include <GL/glew.h>
#include <GL/gl.h>
#include <stdio.h>
#include <assert.h>

#include "openhmd.h"
#include "platform.h"

#define TEST_WIDTH 1280
#define TEST_HEIGHT 800

#define EYE_WIDTH (TEST_WIDTH / 2 * 2)
#define EYE_HEIGHT (TEST_HEIGHT * 2)


GLuint compile_shader(const char* vertex, const char* fragment);
void create_fbo(int eye_width, int eye_height, GLuint* fbo, GLuint* color_tex, GLuint* depth_tex);

// gets float values from the device and prints them
void print_infof(ohmd_device* hmd, const char* name, int len, ohmd_float_value val)
{
    float f[len];
    ohmd_device_getf(hmd, val, f);
    printf("%-20s", name);
    for(int i = 0; i < len; i++)
        printf("%f ", f[i]);
    printf("\n");
}

static ohmd_context* ctx;
static ohmd_device* hmd;
GLuint shader = 0;
GLuint left_color_tex = 0, left_depth_tex = 0, left_fbo = 0;
GLuint right_color_tex = 0, right_depth_tex = 0, right_fbo = 0;

int initOculus()
{
    ctx = ohmd_ctx_create();

    // Probe for devices
    int num_devices = ohmd_ctx_probe(ctx);
    if(num_devices < 0){
        fprintf(stderr, "oculusOpenHMD.dll : Failed to probe devices: %s\n", ohmd_ctx_get_error(ctx));
        return -1;
    }

    if (num_devices <2)
        fprintf(stderr, "\n\t\tWARNING : NO OCULUS HMD CONNECTED\n\n");

    // Open device 0
    hmd = ohmd_list_open_device(ctx, 0);
    if(!hmd){
        fprintf(stderr, "oculusOpenHMD.dll : Failed to open device: %s\n", ohmd_ctx_get_error(ctx));
        return -1;
    }

    // Print information for the opened device
    printf("oculusOpenHMD.dll : Using %s by %s ", ohmd_list_gets(ctx, 0, OHMD_PRODUCT), ohmd_list_gets(ctx, 0, OHMD_VENDOR));
    int ivals[2];
    ohmd_device_geti(hmd, OHMD_SCREEN_HORIZONTAL_RESOLUTION, ivals);
    ohmd_device_geti(hmd, OHMD_SCREEN_VERTICAL_RESOLUTION, ivals + 1);
    printf("(%i x %i).\n", ivals[0], ivals[1]);

//    print_infof(hmd, "hsize:",            1, OHMD_SCREEN_HORIZONTAL_SIZE);
//    print_infof(hmd, "vsize:",            1, OHMD_SCREEN_VERTICAL_SIZE);
//    print_infof(hmd, "lens separation:",  1, OHMD_LENS_HORIZONTAL_SEPARATION);
//    print_infof(hmd, "lens vcenter:",     1, OHMD_LENS_VERTICAL_POSITION);
//    print_infof(hmd, "left eye fov:",     1, OHMD_LEFT_EYE_FOV);
//    print_infof(hmd, "right eye fov:",    1, OHMD_RIGHT_EYE_FOV);
//    print_infof(hmd, "left eye aspect:",  1, OHMD_LEFT_EYE_ASPECT_RATIO);
//    print_infof(hmd, "right eye aspect:", 1, OHMD_RIGHT_EYE_ASPECT_RATIO);
//    print_infof(hmd, "distortion k:",     6, OHMD_DISTORTION_K);

//    printf("\n");

    return num_devices;
}

void endOculus()
{

    ohmd_ctx_destroy(ctx);

}



static void compile_shader_src(GLuint shader, const char* src)
{
//    printf("compiling shader:\n%s\n", src);

    glShaderSource(shader, 1, &src, NULL);
    glCompileShader(shader);

    GLint status;
    GLint length;
    char log[4096] = {0};

    glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
    glGetShaderInfoLog(shader, 4096, &length, log);
    if(status == GL_FALSE){
        printf("compile failed %s\n", log);
    }
}

GLuint compile_shader(const char* vertex, const char* fragment)
{

    // Create the handels
//    printf("creating vertex shader\n");
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);

//    printf("creating fragment shader\n");
    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);

//    printf("creating GLSL program\n");
    GLuint programShader = glCreateProgram();

    // Attach the shaders to a program handel.
    glAttachShader(programShader, vertexShader);
    glAttachShader(programShader, fragmentShader);

    // Load and compile the Vertex Shader
    compile_shader_src(vertexShader, vertex);

    // Load and compile the Fragment Shader
    compile_shader_src(fragmentShader, fragment);

    // The shader objects are not needed any more,
    // the programShader is the complete shader to be used.
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    glLinkProgram(programShader);

    GLint status;
    GLint length;
    char log[4096] = {0};

    glGetProgramiv(programShader, GL_LINK_STATUS, &status);
    glGetProgramInfoLog(programShader, 4096, &length, log);
    if(status == GL_FALSE){
        fprintf(stderr, "oculusOpenHMD.dll : GLSL Program link failed %s\n", log);
    }

    return programShader;
}

void create_fbo(int eye_width, int eye_height, GLuint* fbo, GLuint* color_tex, GLuint* depth_tex)
{
    glGenTextures(1, color_tex);
    glGenTextures(1, depth_tex);
    glGenFramebuffers(1, fbo);

    glBindTexture(GL_TEXTURE_2D, *color_tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, eye_width, eye_height, 0, GL_RGBA, GL_UNSIGNED_INT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glBindTexture(GL_TEXTURE_2D, *depth_tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, eye_width, eye_height, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glBindTexture(GL_TEXTURE_2D, 0);

    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, *fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, *color_tex, 0);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, *depth_tex, 0);

    GLenum status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);

    if(status != GL_FRAMEBUFFER_COMPLETE_EXT){
        printf("oculusOpenHMD.dll : failed to create fbo %x\n", status);
    }
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
}

char* read_file(const char* filename)
{
    FILE* f = fopen(filename, "r");
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);

    char* buffer = (char *) calloc(1, len + 1);
    assert(buffer);

    assert( fread(buffer, len, 1, f) );

    fclose(f);

    return buffer;
}



void updateGL()
{
    static bool glinitialized = false;

    if (!glinitialized ) {

    glewInit();
//    printf("oculusOpenHMD.dll : Initializing Oculus deformation shaders\n");


    char* vertex = "#version 120\n"
            "void main(void)\n"
            "{   gl_TexCoord[0] = gl_MultiTexCoord0;\n"
            "gl_Position = ftransform();\n"
            "}\n";


    char* fragment = "#version 120\n"
            "uniform sampler2D warpTexture;\n"

            "const vec2 LeftLensCenter = vec2(0.2863248, 0.5);\n"
            "const vec2 RightLensCenter = vec2(0.7136753, 0.5);\n"
            "const vec2 LeftScreenCenter = vec2(0.25, 0.5);\n"
            "const vec2 RightScreenCenter = vec2(0.75, 0.5);\n"
            "const vec2 Scale = vec2(0.1469278, 0.2350845);\n"
            "const vec2 ScaleIn = vec2(4, 2.5);\n"
            "const vec4 HmdWarpParam   = vec4(1, 0.22, 0.24, 0);\n"

            "vec2 HmdWarp(vec2 in01, vec2 LensCenter)"
            "{\n"
            "vec2 theta = (in01 - LensCenter) * ScaleIn; \n"
            "float rSq = theta.x * theta.x + theta.y * theta.y;\n"
            "vec2 rvector = theta * (HmdWarpParam.x + HmdWarpParam.y * rSq +"
            "HmdWarpParam.z * rSq * rSq +"
            " HmdWarpParam.w * rSq * rSq * rSq);\n"
            "return LensCenter + Scale * rvector;\n"
            "}"

            "void main()"
            "{\n"
            "vec2 LensCenter = gl_FragCoord.x < 640 ? LeftLensCenter : RightLensCenter;\n"
            "vec2 ScreenCenter = gl_FragCoord.x < 640 ? LeftScreenCenter : RightScreenCenter;\n"

            "vec2 oTexCoord = gl_FragCoord.xy / vec2(1280, 800);\n"

            "vec2 tc = HmdWarp(oTexCoord, LensCenter);\n"
            "if (any(bvec2(clamp(tc,ScreenCenter-vec2(0.25,0.5), ScreenCenter+vec2(0.25,0.5)) - tc)))"
            " {"
            "gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);\n"
            "return;\n"
            "  }\n"

            " tc.x = gl_FragCoord.x < 640 ? (2.0 * tc.x) : (2.0 * (tc.x - 0.5));\n"
            " gl_FragColor = texture2D(warpTexture, tc);\n"
            " }\n";

        shader = compile_shader(vertex, fragment);
        glUseProgram(shader);
        glUniform1i(glGetUniformLocation(shader, "warpTexture"), 0);
        glUseProgram(0);

        //GLuint list = gen_cubes();
        create_fbo(EYE_WIDTH, EYE_HEIGHT, &left_fbo, &left_color_tex, &left_depth_tex);
        create_fbo(EYE_WIDTH, EYE_HEIGHT, &right_fbo, &right_color_tex, &right_depth_tex);

        glinitialized = true;
    }

    ohmd_ctx_update(ctx);
}


void prerenderLeftEye(double eyeX, double eyeY, double eyeZ, double centerX, double centerY, double centerZ, double upX, double upY, double upZ)
{
    float matrix[16];

    // Common scene state
    glEnable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);

    // set hmd rotation, for left eye.
    glMatrixMode(GL_PROJECTION);
    ohmd_device_getf(hmd, OHMD_LEFT_EYE_GL_PROJECTION_MATRIX, matrix);
    glLoadMatrixf(matrix);

    glMatrixMode(GL_MODELVIEW);
    ohmd_device_getf(hmd, OHMD_LEFT_EYE_GL_MODELVIEW_MATRIX, matrix);
    glLoadMatrixf(matrix);
    gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);

    // Draw scene into framebuffer.
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, left_fbo);
    glViewport(0, 0, EYE_WIDTH, EYE_HEIGHT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}


void prerenderRightEye(double eyeX, double eyeY, double eyeZ, double centerX, double centerY, double centerZ, double upX, double upY, double upZ)
{
    float matrix[16];

    // Common scene state
    glEnable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);

    // set hmd rotation, for right eye.
    glMatrixMode(GL_PROJECTION);
    ohmd_device_getf(hmd, OHMD_RIGHT_EYE_GL_PROJECTION_MATRIX, matrix);
    glLoadMatrixf(matrix);

    glMatrixMode(GL_MODELVIEW);
    ohmd_device_getf(hmd, OHMD_RIGHT_EYE_GL_MODELVIEW_MATRIX, matrix);
    glLoadMatrixf(matrix);
    gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);

    // Draw scene into framebuffer.
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, right_fbo);
    glViewport(0, 0, EYE_WIDTH, EYE_HEIGHT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}


//void testgl(void)
//{

//    if (glewGetExtension("GL_ARB_fragment_program"))
//    {
//        printf("Looks like ARB_fragment_program is supported\n");
//    }

//    glViewport(0, 0, TEST_WIDTH, TEST_HEIGHT);
//    glEnable(GL_TEXTURE_2D);
//    glColor4d(1, 1, 1, 1);


//}

void draw(void)
{
    // Clean up common draw state
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
    glDisable(GL_BLEND);
    glDisable(GL_DEPTH_TEST);


    // Setup ortho state.
    glUseProgram(shader);
    glViewport(0, 0, TEST_WIDTH, TEST_HEIGHT);
    glEnable(GL_TEXTURE_2D);
    glColor4d(1, 1, 1, 1);

    // Setup simple render state
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Draw left eye
    glBindTexture(GL_TEXTURE_2D, left_color_tex);
    glBegin(GL_QUADS);
    glTexCoord2d( 0,  0);
    glVertex3d(  -1, -1, 0);
    glTexCoord2d( 1,  0);
    glVertex3d(   0, -1, 0);
    glTexCoord2d( 1,  1);
    glVertex3d(   0,  1, 0);
    glTexCoord2d( 0,  1);
    glVertex3d(  -1,  1, 0);
    glEnd();

    // Draw right eye
    glBindTexture(GL_TEXTURE_2D, right_color_tex);
    glBegin(GL_QUADS);
    glTexCoord2d( 0,  0);
    glVertex3d(   0, -1, 0);
    glTexCoord2d( 1,  0);
    glVertex3d(   1, -1, 0);
    glTexCoord2d( 1,  1);
    glVertex3d(   1,  1, 0);
    glTexCoord2d( 0,  1);
    glVertex3d(   0,  1, 0);
    glEnd();

    // Clean up state.
    glBindTexture(GL_TEXTURE_2D, 0);
    glDisable(GL_TEXTURE_2D);
    glUseProgram(0);

}


