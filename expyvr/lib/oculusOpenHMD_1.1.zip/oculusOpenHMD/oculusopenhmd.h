#ifndef OCULUSOPENHMD_H
#define OCULUSOPENHMD_H

#include "oculusopenhmd_global.h"


extern "C" {

OCULUSOPENHMDSHARED_EXPORT int initOculus(void);
OCULUSOPENHMDSHARED_EXPORT void updateGL(void);
OCULUSOPENHMDSHARED_EXPORT void endOculus(void);


OCULUSOPENHMDSHARED_EXPORT void prerenderLeftEye(double eyeX, double eyeY, double eyeZ, double centerX, double centerY, double centerZ, double upX, double upY, double upZ);
OCULUSOPENHMDSHARED_EXPORT void prerenderRightEye(double eyeX, double eyeY, double eyeZ, double centerX, double centerY, double centerZ, double upX, double upY, double upZ);
OCULUSOPENHMDSHARED_EXPORT void draw(void);

//OCULUSOPENHMDSHARED_EXPORT void testgl(void);
}

#endif // OCULUSOPENHMD_H
