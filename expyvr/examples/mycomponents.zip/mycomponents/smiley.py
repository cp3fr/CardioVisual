'''
smiley.py
Created on Jan, 16 2012
@author: bruno 
'''
from pyglet.gl import *
from abstract.AbstractClasses import DrawableHUDModule

class ModuleMain(DrawableHUDModule):
    """
    A simple module to display a smiley
    """
    defaultInitConf = {
        'name': 'smiley'
    }
    
    defaultRunConf = {    
        'color': (255, 255, 0, 255),
        'size': 200
    }
    
    confDescription = [
        ('name', 'str', "smile"),
        ('size', 'int', "Size of smiley pixels"),
        ('color', 'code', "Color in rgba [0..255], e.g. (255,0,0,255)")
    ]
    
    def __init__(self, controller, initConfig=None, runConfigs=None):
        """
        Initialise the module with the given init configuration and run configurations
        """
        DrawableHUDModule.__init__(self, controller, initConfig, runConfigs)
        
        # create class member variables
        self.label = None
        self.labels = {}
        
        # fill the hash table with labels to draw the smileys
        for conf in self.runConfs:  
            self.labels[conf] = pyglet.text.Label(text=':)', color=self.runConfs[conf]['color'],
                                                  font_name='consolas', font_size=self.runConfs[conf]['size'],
                                                  anchor_x='center', anchor_y='center',
                                                  x=0, y=0)
    
    def draw(self, window_width, window_height):
        """
        Draw the module
        """
        DrawableHUDModule.draw(self, window_width, window_height)

        # center text
        glTranslatef(window_width * 0.5, window_height * 0.5, 0.0)
        # rotate smiley head up
        glRotatef(-90, 0, 0, 1)
        # draw it
        self.label.draw()
        
        
    def start(self, dt=0, duration=-1, configName=None):
        """
        Activate the module with the parameters passed in the conf
        """
        DrawableHUDModule.start(self, dt, duration, configName)
        
        # select the current label to draw
        self.label = self.labels[configName]


